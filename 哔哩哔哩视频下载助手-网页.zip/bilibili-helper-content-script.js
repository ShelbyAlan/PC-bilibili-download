(function() {
    var x={16:"360P",32:"480P",64:"720P",80:"1080P",112:"1080P 高码率",120:"4K",125:"HDR"},B="bilibili-helper-host",G="bilibili-helper-ext-content-script",Q="ffmpeg.worker.js",Y="ffmpeg-core.js",S="ffmpeg-core.wasm", $="ffmpeg-core.worker.js",P="//api.bilibili.com/x/player/wbi/playurl";var V={credentials:"include"},E={OK:0,FAILED_TO_FETCH:-1,INVALID_RESPONSE:-2,VIP_ONLY:-10403,UNKNOWN:-99999};
    var f=(...e)=>{},w=()=>location.hostname==="www.bilibili.com"||location.hostname==="bilibili.com",j=()=>/\/video\/(av|bv)[0-9a-zA-Z]+/i.test(window.location.pathname),y=()=>/\/bangumi\/play\/\S+/i.test(window.location.pathname),C=e=>{if(!e)return"";let i=1024*1024*1024,d=1024*1024,o=1024;return e>=i?`${(e/i).toFixed(2)}GB`:e>=d?`${(e/d).toFixed(2)}MB`:e>=o?`${(e/o).toFixed(2)}KB`:e+"B"},M=()=>localStorage.bilibili_helper_download_mode!=="normal",k=()=>localStorage.bilibili_helper_merge_mode!=="off",h=()=>true,F=()=>{let e=document.getElementById(G);if(!e)return {baseUrl:""};let{manifest:m,baseUrl:i}=JSON.parse(e.dataset.internals);return{...m,baseUrl:i}};

    var N0 = `
    :host { --primary: #fb7299; --primary-hover: #ff85ad; --bg: #ffffff; --text: #222222; --text-sub: #61666d; --border: #e3e5e7; --card-bg: #f6f7f8; --shadow: 0 12px 40px rgba(0,0,0,0.15); }
    .dark :host, .dark { --bg: #1e1e1e; --text: #e3e5e7; --text-sub: #9499a0; --border: #333333; --card-bg: #2d2d2d; --shadow: 0 12px 40px rgba(0,0,0,0.4); }
    #wrapper { position: fixed; right: 20px; bottom: 20px; width: 300px; height: auto; max-height: 550px; background: var(--bg); border-radius: 16px; box-shadow: var(--shadow); z-index: 2147483647; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; border: 1px solid var(--border); color: var(--text); overflow: hidden; transform-origin: bottom right; transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease, visibility 0.3s; transform: scale(1); opacity: 1; }
    #wrapper.minimized { transform: scale(0); opacity: 0; visibility: hidden; pointer-events: none; }
    #mini-icon { position: fixed; right: 20px; bottom: 20px; display: none; width: 64px; height: 36px; align-items: center; justify-content: center; background: var(--primary); color: white; border-radius: 18px; cursor: pointer; z-index: 2147483647; box-shadow: var(--shadow); transition: transform 0.2s; }
    #mini-icon:hover { transform: scale(1.05); }
    :host #wrapper.minimized + #mini-icon { display: flex; }
    #container { padding: 18px; display: flex; flex-direction: column; gap: 12px; box-sizing: border-box; }
    .header { display: flex; justify-content: space-between; align-items: center; }
    #theme-toggle, #close-btn { opacity: 0.7; cursor: pointer; transition: 0.2s; }
    #theme-toggle:hover, #close-btn:hover { opacity: 1; }
    .section-box { background: var(--card-bg); border-radius: 10px; padding: 12px; border: 1px solid var(--border); }
    .title-text { font-size: 13px; font-weight: 600; color: var(--text); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .quality-section { display: flex; flex-direction: column; gap: 8px; }
    .label-name { font-size: 12px; color: var(--text-sub); }
    .label-val { font-size: 12px; font-weight: bold; color: var(--primary); background: rgba(251, 114, 153, 0.1); padding: 4px 10px; border-radius: 6px; width: fit-content; border: 1px solid rgba(251, 114, 153, 0.2); }
    .radio-group { display: flex; gap: 16px; margin-top: 8px; }
    .radio-group label { font-size: 12px; display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-sub); }
    .btn-dl { display: flex; align-items: center; justify-content: center; width: 100%; padding: 10px 0; background: var(--primary); color: white !important; border-radius: 10px; text-align: center; text-decoration: none; font-weight: bold; font-size: 13px; margin-top: 6px; transition: 0.2s; }
    .btn-dl:hover { filter: brightness(1.05); transform: translateY(-1px); }
    .progress-bar { height: 6px; background: var(--border); border-radius: 10px; overflow: hidden; margin: 10px 0; }
    .progress-inner { height: 100%; background: var(--primary); transition: width 0.3s; }
    .status-ok { display: flex; align-items: center; justify-content: center; color: #00b578; font-weight: bold; font-size: 12px; }
    `;

    var n0=`
    <div id="wrapper">
      <div id="container">
        <div class="header">
          <h3 style="margin:0; font-size:14px; color:var(--primary);">哔哩哔哩视频下载助手</h3>
          <div style="display:flex; gap:10px; align-items:center;">
            <div id="theme-toggle">🌙</div>
            <div id="close-btn" style="font-size:20px;">×</div>
          </div>
        </div>
        <div class="section-box"><div id="video-title" class="title-text">正在识别视频...</div></div>
        <div class="section-box quality-section">
          <span class="label-name">当前画质</span>
          <span id="quality-val" class="label-val">-</span>
        </div>
        <div class="section-box">
          <span class="label-name">设置</span>
          <div class="radio-group">
            <label><input id="setting-download-mode-advanced" checked name="dl-mode" type="radio" /> 高级</label>
            <label><input id="setting-download-mode-normal" name="dl-mode" type="radio" /> 兼容</label>
          </div>
        </div>
        <div id="durls-list"></div>
      </div>
    </div>
    <div id="mini-icon">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
    </div>
    `;

    var Z0=e=>{
      let host = document.getElementById(B);
      let w=e.getElementById("wrapper"), mini=e.getElementById("mini-icon"), cls=e.getElementById("close-btn"), tBtn=e.getElementById("theme-toggle"), durls=e.getElementById("durls-list");
      const minimize = () => { w.classList.add("minimized"); localStorage.bilibili_helper_show="hide"; };
      const expand = () => { w.classList.remove("minimized"); localStorage.bilibili_helper_show="show"; };
      mini.onclick= (ev) => { ev.stopPropagation(); expand(); };
      cls.onclick= (ev) => { ev.stopPropagation(); minimize(); };
      window.addEventListener('click', (ev) => { if (host && !host.contains(ev.target)) { minimize(); } }, true);
      w.onclick = (ev) => { ev.stopPropagation(); };
      minimize(); 
      const applyTheme=dk=>{ if(dk){ w.classList.add("dark"); tBtn.innerText="🌙"; }else{ w.classList.remove("dark"); tBtn.innerText="☀️"; } };
      applyTheme(localStorage.getItem("bilibili_helper_theme")==="dark");
      tBtn.onclick=()=>{ let dk=!w.classList.contains("dark"); applyTheme(dk); localStorage.setItem("bilibili_helper_theme",dk?"dark":"light"); };
      durls.onclick=b=>{
        let g=b.target;
        if(g.tagName==="A" && g.getAttribute("mode")==="advanced"){
          let target=e.querySelector(`div[durls="${g.getAttribute("durls")}"]`);
          t0(!0,g,JSON.parse(decodeURIComponent(g.getAttribute("durls"))),g.getAttribute("title"),target);
        }
      };
    };

    var A=e=>new Promise(i=>{let d=0,o=setInterval(()=>{d++;let a=document.querySelector(e);(a||d>100)&&(clearInterval(o),o=null,i(a))},300)});
    var X=async(e)=>{ let lastUrl = ""; setInterval(async () => { const curUrl = window.location.href; const player = document.querySelector("#bilibili-player, .bpx-player-container, .squirtle-video-container"); if(player && (curUrl !== lastUrl || !document.getElementById(B))){ lastUrl = curUrl; e(); } }, 2000); };
    var H=e=>{if(!e.customElements.get(B))e.customElements.define(B,class extends HTMLElement{constructor(){super()}})};
    var m0=async()=>{let e=document.querySelector(".squirtle-quality-select-list li.active, .bpx-player-ctrl-quality-menu .bpx-state-active");if(!e)return null;return +e.dataset.value||null};
    var z=async()=>{let e=localStorage.bilibili_player_settings&&`${localStorage.bilibili_player_settings}`!="undefined"&&+JSON.parse(localStorage.bilibili_player_settings).setting_config.defquality||120;return e=await m0()||e,e};
    var u;(function(e){e.LOAD="LOAD",e.EXEC="EXEC",e.WRITE_FILE="WRITE_FILE",e.READ_FILE="READ_FILE",e.DELETE_FILE="DELETE_FILE",e.RENAME="RENAME",e.CREATE_DIR="CREATE_DIR",e.LIST_DIR="LIST_DIR",e.DELETE_DIR="DELETE_DIR",e.ERROR="ERROR",e.DOWNLOAD="DOWNLOAD",e.PROGRESS="PROGRESS",e.LOG="LOG"})(u||(u={}));
    var b0=(()=>{let e=0;return()=>e++})(),e0=class{#e=null;#a={};#d={};#o=[];#t=[];loaded=!1;constructor({worker:e}){this.#e=e,this.#r()}#r=()=>{this.#e&&(this.#e.onmessage=({data:{id:e,type:i,data:d}})=>{switch(i){case u.LOAD:this.loaded=!0,this.#a[e](d);break;case u.EXEC:case u.WRITE_FILE:case u.READ_FILE:case u.DELETE_FILE:case u.RENAME:case u.CREATE_DIR:case u.LIST_DIR:case u.DELETE_DIR:this.#a[e](d);break;case u.LOG:this.#o.forEach(o=>o(d));break;case u.PROGRESS:this.#t.forEach(o=>o(d));break;case u.ERROR:this.#d[e](d);break}delete this.#a[e],delete this.#d[e]})};#i=({type:e,data:i},d=[])=>this.#e?new Promise((o,a)=>{let r=b0();this.#e&&this.#e.postMessage({id:r,type:e,data:i},d),this.#a[r]=o,this.#d[r]=a}):Promise.reject();on(e,i){e==="log"?this.#o.push(i):e==="progress"&&this.#t.push(i)}load=(e={})=>(this.#e||(this.#e=new Worker(new URL("./worker.js",import.meta.url),{type:"module"}),this.#r()),this.#i({type:u.LOAD,data:e}));exec=(e,i=-1)=>this.#i({type:u.EXEC,data:{args:e,timeout:i}});writeFile=(e,i)=>{let d=[];return i instanceof Uint8Array&&d.push(i.buffer),this.#i({type:u.WRITE_FILE,data:{path:e,data:i}},d)};readFile=(e,i="binary")=>this.#i({type:u.READ_FILE,data:{path:e,encoding:i}});deleteFile=e=>this.#i({type:u.DELETE_FILE,data:{path:e}});terminate=()=>{this.#e&&(this.#e.terminate(),this.#e=null,this.loaded=!1)}};
    var D=async e=>{let i;if(typeof e=="string")i=await(await fetch(e)).arrayBuffer();else if(e instanceof URL)i=await(await fetch(e)).arrayBuffer();else return new Uint8Array;return new Uint8Array(i)},J=async(e,i)=>{let a=await(await fetch(e)).arrayBuffer(),r=new Blob([a],{type:i});return URL.createObjectURL(r)},W=async e=>{try{if(e==="next2025"&&window.__PLAYURL_HYDRATE_DATA__)return{data:window.__PLAYURL_HYDRATE_DATA__,code:0};let d=await(await window.fetch(window.location.href,V)).text(),o=d.match(/<script>window.__INITIAL_STATE__=(.+?)<\/script>/);if(o&&o[1]){let N=JSON.parse(o[1].replace(";(function(){var s;(s=document.currentScript||document.scripts[document.scripts.length-1]).parentNode.removeChild(s);}());",""));return{code:E.OK,data:N}}return{code:E.INVALID_RESPONSE}}catch(i){return{code:E.FAILED_TO_FETCH}}},T0=async e=>{let i=new e0({worker:new Worker(await J(`${e}/${Q}`,"text/javascript"),{type:"module"})});await i.load({coreURL:await J(`${e}/${Y}`,"text/javascript"),wasmURL:await J(`${e}/${S}`,"application/wasm"),workerURL:await J(`${e}/${$}`,"text/javascript")});return i},_0=async(e,i,d)=>{let o=`${Date.now()}`,a=await T0(e),r=`${o}_a.mp4`,N=`${o}_v.mp4`,t=`${o}_m.mp4`;await a.writeFile(r,new Uint8Array(i)),await a.writeFile(N,new Uint8Array(d)),await a.exec(`-i ${N} -i ${r} -vcodec copy -acodec copy ${t}`.split(" "));let n=await a.readFile(t);return[n.buffer,()=>a.terminate()]},U=(e,i,d)=>{if(i.dash||i.durl){let{dash:r,support_formats:c}=i;c.forEach(s=>{x[s.quality]=s.new_description||x[s.quality]});let p=r?.video?.find(s=>`${s.id}`==`${d}`)??r?.video?.[0],m=r?.audio?.[0];return{code:E.OK,dash:m&&p?{audio:m,video:p}:void 0,durl:i.durl,qualityDescription:x[p?.id??d]}}return {code:E.INVALID_RESPONSE}},i0=async(e=120,i)=>U(null,i,e),d0=async(e,i,d,o=120)=>{let a=`${P}?qn=${o}&fnver=0&fnval=4048&fourk=1&avid=${e}&bvid=${i}&cid=${d}`,N=await(await window.fetch(a,V)).json();return U(null,N.data,o)},a0=(e,i,d)=>{let a=new Blob([e],{type:"application/octet-stream"}),r=document.createElement("a"),N=URL.createObjectURL(a);r.setAttribute("href",N),r.setAttribute("download",i),r.setAttribute("style","color:var(--primary);font-size:12px;display:block;margin-top:5px;"),r.innerHTML="[点击保存到本地]",d.appendChild(r),r.click()},o0=async(e,i,d)=>{let a=await fetch(e),r=parseInt(a.headers.get("content-length"),10),t=0;return await new Response(new ReadableStream({start(c){let l=a.body.getReader(),p=()=>{l.read().then(({done:m,value:s})=>{if(m){c.close();return}t+=s.byteLength,c.enqueue(s),d(t,r),p()})};p()}})).blob()},R=async(e,{url:i,size:d},o,a)=>{e.classList.add("disabled");try{let r=await o0(i,d,(t,n)=>{let c=Math.ceil(t/n*100);a.innerHTML=`<div class="progress-bar"><div class="progress-inner" style="width:${c}%"></div></div><div style="font-size:11px;text-align:right;color:var(--text)">${c}%</div>`});a.innerHTML="<span class='status-ok'>下载成功</span>";a0(r,o+".mp4",a)}finally{e.classList.remove("disabled")}},t0=async(e,i,d,o,a)=>{i.classList.add("disabled");a.innerHTML="";let r=d.map(async({url:N,size:t},n)=>{let p=document.createElement("div");p.innerHTML=`<div style="font-size:11px;color:var(--text)">${n===0?"音频":"视频"}</div><div class="progress-bar"><div class="progress-inner" id="pb-${n}"></div></div>`;a.appendChild(p);let inner=p.querySelector(".progress-inner");let blob=await o0(N,t,(s,b)=>inner.style.width=Math.ceil(s/b*100)+"%");return await blob.arrayBuffer()});try{let buffers=await Promise.all(r);a.innerHTML='<div style="font-size:12px;color:var(--primary);margin:8px 0;">正在合并中...</div>';let{baseUrl:n}=F(),[c,l]=await _0(n,buffers[0],buffers[1]);a.innerHTML='<span class="status-ok">合并完成！</span>';a0(c,o+".mp4",a),l()}finally{i.classList.remove("disabled")}},r0=(e,i,d)=>{let o=i.prototype.open;i.prototype.open=function(a,r){this.addEventListener("readystatechange",function(){if(this.readyState===4&&this.status===200&&r.indexOf("/playurl?")!==-1){try{let N=JSON.parse(this.responseText);N.data&&e(N.data)}catch(t){}}},!1),o.apply(this,arguments)}};
    var L=({title:e,code:i,dash:d,quality:o,durl:a})=>{
      if(i!==E.OK) return "";
      let isDash=!!d, list=isDash?[{url:d.audio.base_url,size:d.audio.size},{url:d.video.base_url,size:d.video.size}]:a;
      if(!M()) return list.map((N,t)=>`<a class="btn-dl" download="${e}.mp4" href="${N.url}">直接下载 ${isDash?(t==0?"音":"视")+(t+1):""}</a>`).join("");
      return `<div><a class="btn-dl" durls="${encodeURIComponent(JSON.stringify(list))}" mode="advanced" merge="on" title="${e}" href="javascript:;">合并下载</a><div class="progress" durls="${encodeURIComponent(JSON.stringify(list))}"></div></div>`;
    };

    var T=({code:e,title:i,dash:d,quality:o,loading:ld,durl:a})=>{
      let t=document.getElementById(B);
      if(!t){
        t=document.createElement(B); t.id=B; document.body.appendChild(t);
        let n=t.attachShadow({mode:"open"}); n.innerHTML=`<style>${N0}</style>${n0}`;
        Z0(n);
      }
      let sr=t.shadowRoot;
      sr.getElementById("quality-val").innerText=o||"-";
      sr.getElementById("video-title").innerText=ld?"正在识别中...":i;
      sr.getElementById("durls-list").innerHTML=ld?"":L({title:i,code:e,dash:d,quality:o,durl:a});
      if(localStorage.bilibili_helper_show === "hide") { sr.getElementById("wrapper").classList.add("minimized"); }
    };
    var s0=async()=>{let e=await W(),i=await z();if(e.code)return T({code:e.code,quality:x[i]});let d=e.data.videoData,o=d.aid,a=d.bvid,r=d.cid;let N,t;if(d.pages.length>1){let m=location.search.match(/p=(\d+)/),s=d.pages[0];if(m&&m[1])s=d.pages.find(b=>""+b.page==""+m[1]);N=s.page,t=s.part,r=s.cid}let{code:n,dash:c,qualityDescription:l}=await d0(o,a,r,i);let m=d.title;if(N&&t)m=`${d.title}_P${N}_${t}`;T({code:n,title:m,quality:l,dash:c})},c0=async e=>{let r=await z(),o=await W("next2025");if(o.code)return T({code:o.code,quality:x[r]});let{code:l,dash:p,qualityDescription:m,durl:b}=await i0(r,e);T({code:l,title:document.title.split("_")[0],dash:p,quality:m,durl:b})};
    var Z={videoInfo:null};
    var y0=async e=>{H(e);let d=async()=>{if(!w()||(!j()&&!y()))return;T({loading:!0});if(j())s0();if(y())c0(Z.videoInfo)}; if(y())r0(o=>{Z.videoInfo=o;d()},window.XMLHttpRequest,()=>d());else X(d)};y0(window);
})();